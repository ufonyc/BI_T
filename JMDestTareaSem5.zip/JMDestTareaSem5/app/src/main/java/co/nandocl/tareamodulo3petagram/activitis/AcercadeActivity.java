package co.nandocl.tareamodulo3petagram.activitis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import co.nandocl.tareamodulo3petagram.R;

public class AcercadeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acercade);
    }
}