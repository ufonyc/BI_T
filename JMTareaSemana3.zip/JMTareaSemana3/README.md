# Coursera Desarrollo Tarea Semana 3

## Captura de pantalla de aplicacion en archivo "capturaTarea.png"
