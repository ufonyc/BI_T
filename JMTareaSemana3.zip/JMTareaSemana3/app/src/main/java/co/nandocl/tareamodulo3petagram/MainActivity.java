package co.nandocl.tareamodulo3petagram;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewMascota;
    private ReciclerViewAdaptador adaptadorMascota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.action_bar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("sem3_Tarea_3");

        recyclerViewMascota = findViewById(R.id.reciclerMascota);
        recyclerViewMascota.setLayoutManager(new LinearLayoutManager(this));

        adaptadorMascota = new ReciclerViewAdaptador(obtenerMascotas());
        recyclerViewMascota.setAdapter(adaptadorMascota);
    }

    public List<MascotaModelo> obtenerMascotas(){
        List<MascotaModelo> mascota = new ArrayList<>();
        mascota.add(new MascotaModelo("Rocco", 0, R.drawable.ct1));
        mascota.add(new MascotaModelo("Samito", 1, R.drawable.ct2));
        mascota.add(new MascotaModelo("Tom", 2, R.drawable.ct3));
        mascota.add(new MascotaModelo("Lola", 3, R.drawable.ct4));
        mascota.add(new MascotaModelo("kevin", 4, R.drawable.ct5));
        mascota.add(new MascotaModelo("Piky", 5, R.drawable.ct6));

        return mascota;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.toString().equals("favorito")){
            Intent intent = new Intent(this, Favorito.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}