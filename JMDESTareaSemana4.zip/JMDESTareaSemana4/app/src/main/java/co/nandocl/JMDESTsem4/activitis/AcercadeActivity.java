package co.nandocl.JMDESTsem4.activitis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import co.nandocl.JMDESTsem4.R;

public class AcercadeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acercade);
    }
}