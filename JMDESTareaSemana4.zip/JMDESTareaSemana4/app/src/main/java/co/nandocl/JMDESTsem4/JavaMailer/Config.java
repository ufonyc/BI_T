package co.nandocl.JMDESTsem4.JavaMailer;

public class Config {
    public static final String EMAIL ="MI_CORREO@gmail.com";
    public static final String PASSWORD ="MI_PASSWORD";
}
